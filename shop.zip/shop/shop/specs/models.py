from django.db import models


class CategoryFeature(models.Model):
    """
    Charakterystyka określonej kategorii
    """
    category = models.ForeignKey('mainapp.Category', verbose_name='Kategoria', on_delete=models.CASCADE)
    feature_name = models.CharField(max_length=100, verbose_name='Nazwa  charakterystyki')
    feature_filter_name = models.CharField(max_length=50, verbose_name='Nazwa filtra')
    unit = models.CharField(max_length=50, verbose_name='Jednostka miary', null=True, blank=True)

    class Meta:
        unique_together = ('category', 'feature_name', 'feature_filter_name')

    def __str__(self):
        return f"{self.category.name} | {self.feature_name}"


class FeatureValidator(models.Model):
    """
    Walidator wartości dla określonej charakterystyki należącej do określonej kategorii
    """
    category = models.ForeignKey('mainapp.Category', verbose_name='Kategoria', on_delete=models.CASCADE)
    feature_key = models.ForeignKey(CategoryFeature, verbose_name='Klucz do charakterystyki', on_delete=models.CASCADE)
    valid_feature_value = models.CharField(max_length=100, verbose_name='Walidowa wartość')

    def __str__(self):
        return f"Kategoria \"{self.category.name}\" | Charakterystyka \"{self.feature_key.feature_name}\" | Walidowa wartość \"{self.valid_feature_value}\""


class ProductFeatures(models.Model):
    """
    Charakterystyka produktu
    """
    product = models.ForeignKey('mainapp.Product', verbose_name='Produkt', on_delete=models.CASCADE)
    feature = models.ForeignKey(CategoryFeature, verbose_name='Charakterystyka', on_delete=models.CASCADE)
    value = models.CharField(max_length=255, verbose_name='Wartość')

    def __str__(self):
        return f"Produkt - \"{self.product.title} | Charakterystyka - \"{self.feature.feature_name} | Wartość - {self.value}"

        

